"""
vera/verify.py

Third-party verification of VERA session certificates.
Patent Pending — U.S. Application No. 64/000,086 (Claim 12, 13)

A verifier needs only the operator's public key.
No access to the private key, signing service, or any platform required.

This is the "portable" claim — the certificate is fully self-contained.

Usage:
    from vera.verify import verify_certificate, reconstruct_context

    # Verify a single certificate
    valid = verify_certificate(
        cert_path=".vera/sessions/2026-03-09T14-22-01Z.json",
        public_key_path=".vera/keys/public.pem"
    )

    # Reconstruct the full context state at the time of signing
    context = reconstruct_context(cert_path="...")
"""

from pathlib import Path


def verify_certificate(cert_path, public_key_path) -> bool:
    """
    Verify a session certificate against the operator's public key.

    Returns True if the certificate is valid and unmodified.
    Returns False if the signature does not match (record was altered).

    Args:
        cert_path:       Path to the .json certificate file.
        public_key_path: Path to the operator's public.pem file.
    """
    # TODO: implement
    # 1. Load certificate JSON
    # 2. Load public key from public_key_path
    # 3. Reconstruct canonical payload (json.dumps record, sort_keys=True)
    # 4. Decode base64 signature
    # 5. public_key.verify(signature, payload) — raises InvalidSignature if bad
    # 6. Return True if valid, False if exception
    raise NotImplementedError("TODO: implement verify_certificate")


def verify_bundle(bundle_path, public_key_path) -> dict:
    """
    Verify all certificates in a multi-vendor SessionBundle.

    Returns a dict mapping session_id -> bool for each certificate.
    """
    # TODO: implement
    raise NotImplementedError("TODO: implement verify_bundle")


def reconstruct_context(cert_path) -> dict:
    """
    Reconstruct the full context state at the time of signing.
    Implements patent claim 6, 13 — context state reconstruction.

    Returns the context_snapshot dict from the signed record.
    Does NOT require the private key — reconstruction is public.
    """
    # TODO: implement
    # Load certificate, return record["context_snapshot"]
    raise NotImplementedError("TODO: implement reconstruct_context")
