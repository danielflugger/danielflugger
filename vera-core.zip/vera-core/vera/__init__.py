"""
vera — Sovereign Provenance Protocol
Patent Pending — U.S. Application No. 64/000,086
Dhana LLC
"""

__version__ = "0.1.0-skeleton"
__patent__  = "U.S. Appl. No. 64/000,086"
