"""
vera/store.py

Local storage manager for signed session certificates.
Patent Pending — U.S. Application No. 64/000,086 (Claim 10, 11)

All session records are stored locally under .vera/sessions/.
No data is transmitted to any third-party service.
The session index is itself signed to detect tampering.

Storage layout:
    .vera/
    ├── sessions/
    │   ├── 2026-03-09T14-22-01Z.json     # individual certificates
    │   ├── 2026-03-09T15-44-12Z.json
    │   └── ...
    ├── index.json                          # signed session index
    └── keys/
        ├── public.pem                      # committed to git
        └── private.pem                     # NEVER committed
"""

from pathlib import Path
from typing import Iterator
import json


SESSIONS_DIR = Path(".vera/sessions")
INDEX_PATH   = Path(".vera/index.json")


class SessionStore:
    """
    Manages local persistence of signed session certificates.
    """

    def __init__(self, base_dir: Path = Path(".vera")):
        self.base_dir = base_dir
        self.sessions_dir = base_dir / "sessions"

    def write(self, certificate: dict, session_id: str) -> Path:
        """
        Persist a signed certificate. Updates the session index.

        Returns the path the certificate was written to.
        """
        # TODO: implement
        # 1. Ensure sessions_dir exists
        # 2. Write certificate JSON to sessions_dir / f"{session_id}.json"
        # 3. Update and re-sign the session index
        # 4. Return path
        raise NotImplementedError("TODO: implement SessionStore.write")

    def read(self, session_id: str) -> dict:
        """Load a certificate by session ID."""
        # TODO: implement
        raise NotImplementedError("TODO: implement SessionStore.read")

    def list(self) -> Iterator[Path]:
        """Yield paths to all stored session certificates, oldest first."""
        # TODO: implement
        # return sorted(self.sessions_dir.glob("*.json"))
        raise NotImplementedError("TODO: implement SessionStore.list")

    def update_index(self) -> None:
        """
        Rebuild and re-sign the session index.
        Index maps session_id -> {timestamp, model, prompt_hash, path}.
        Signing the index enables detection of any tampering with the store.
        """
        # TODO: implement
        raise NotImplementedError("TODO: implement SessionStore.update_index")
