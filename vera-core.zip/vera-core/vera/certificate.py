"""
vera/certificate.py

Portable Session Certificate format.
Patent Pending — U.S. Application No. 64/000,086 (Claim 9, 12)

A session certificate is the portable, self-verifying output of the
signing engine. It contains everything a third party needs to verify
the record using only the operator's public key — no platform dependency,
no third-party service required.

Certificate structure:
{
    "record": { ...session record... },       # The signed payload
    "signature": "base64-encoded-sig",         # Ed25519 signature
    "public_key_file": ".vera/keys/public.pem" # Path to verifying key
}

Multiple certificates from different LLM vendors can be aggregated
into a single session bundle — the multi-vendor aggregation claim.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
import json


@dataclass
class SessionCertificate:
    """
    Single signed session record for one LLM interaction.
    Portable and self-verifying.
    """
    record: dict
    signature: str          # base64-encoded Ed25519 signature
    public_key_file: str    # relative path to public key

    def to_dict(self) -> dict:
        return {
            "record": self.record,
            "signature": self.signature,
            "public_key_file": self.public_key_file,
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    @classmethod
    def from_dict(cls, data: dict) -> "SessionCertificate":
        return cls(
            record=data["record"],
            signature=data["signature"],
            public_key_file=data["public_key_file"],
        )

    @classmethod
    def from_file(cls, path) -> "SessionCertificate":
        return cls.from_dict(json.loads(Path(path).read_text()))


@dataclass
class SessionBundle:
    """
    Aggregated certificates from multiple LLM vendors for one work session.
    Implements the multi-vendor aggregation claim (patent claim 9, 12).

    A bundle allows a single work session that consulted multiple models
    (e.g. Claude + Gemini + GPT-4) to be represented as one verifiable unit.
    """
    session_id: str
    certificates: list = field(default_factory=list)
    metadata: dict = field(default_factory=dict)

    # TODO: implement aggregate(), verify_all(), to_json()
    # aggregate() — merge certificates from multiple vendors into one bundle
    # verify_all() — verify every certificate in the bundle
    # to_json() — serialize for storage or transmission
