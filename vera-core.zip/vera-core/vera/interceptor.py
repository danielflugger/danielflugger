"""
vera/interceptor.py

MCP-compatible transport interception wrapper.
Patent Pending — U.S. Application No. 64/000,086 (Claims 1, 2, 3)

This module sits between the caller and any LLM provider.
It intercepts the call, passes it through unchanged, then
signs the result — transparent to both sides.

Works identically for:
  - Cloud LLMs (Claude, GPT-4, Gemini via API)
  - Local LLMs (Ollama, LM Studio, any OpenAI-compatible endpoint)
  - MCP tool calls

Usage:
    from vera.interceptor import VERAInterceptor

    # Wrap any callable that takes (prompt) and returns (response string)
    interceptor = VERAInterceptor(model="claude-sonnet-4-6")

    response = interceptor.call(
        prompt="What database should I use for analytics?",
        context_snapshot={"project": "vera-core", "git_ref": "abc123"}
    )
    # Response is identical to unwrapped call.
    # Session certificate written to .vera/sessions/ automatically.
"""

from typing import Callable, Any


class VERAInterceptor:
    """
    Transparent wrapper around any LLM call.
    Intercepts at the transport layer — caller and model are unaware.
    """

    def __init__(self, model: str, provider_fn: Callable | None = None):
        """
        Args:
            model:       Model identifier string for the session record.
            provider_fn: Optional callable (prompt: str) -> str.
                         If None, must be set before calling .call().
        """
        self.model = model
        self.provider_fn = provider_fn

    def call(
        self,
        prompt: str,
        context_snapshot: dict[str, Any] | None = None,
    ) -> str:
        """
        Make an LLM call and sign the result.

        Args:
            prompt:           Prompt to send to the model.
            context_snapshot: Session state to include in the record.

        Returns:
            The model's response string (unmodified).
        """
        # TODO: implement
        # 1. Call self.provider_fn(prompt) to get response
        # 2. Call sign_session(prompt, response, self.model, context_snapshot)
        # 3. Return response unchanged
        raise NotImplementedError("TODO: implement VERAInterceptor.call")

    def wrap(self, provider_fn: Callable) -> "VERAInterceptor":
        """
        Fluent setter for provider_fn. Allows:
            interceptor = VERAInterceptor(model="...").wrap(my_llm_fn)
        """
        self.provider_fn = provider_fn
        return self


class MCPInterceptor(VERAInterceptor):
    """
    Specialisation for MCP-native tool call interception.
    Captures tool name, input schema, and output alongside prompt/response.

    TODO: implement MCP tool call wrapping
    """
    pass
