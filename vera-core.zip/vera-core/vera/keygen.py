"""
vera/keygen.py

Ed25519 keypair generation for the VERA signing engine.
Patent Pending — U.S. Application No. 64/000,086 (Claim 8, 10)

Run once per operator installation:
    python -m vera.keygen
"""

from pathlib import Path


PRIVATE_KEY_PATH = Path(".vera/keys/private.pem")
PUBLIC_KEY_PATH  = Path(".vera/keys/public.pem")


def generate_keypair(force: bool = False) -> None:
    """
    Generate an Ed25519 keypair and write to .vera/keys/.

    Private key stays local — NEVER committed to git.
    Public key is committed and used by third parties to verify certificates.

    Args:
        force: Overwrite existing keypair if True.
    """
    # TODO: implement
    # from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    # from cryptography.hazmat.primitives.serialization import (
    #     Encoding, PrivateFormat, PublicFormat, NoEncryption
    # )
    #
    # if PRIVATE_KEY_PATH.exists() and not force:
    #     raise FileExistsError(
    #         f"Keypair already exists at {PRIVATE_KEY_PATH}. "
    #         "Pass force=True to regenerate."
    #     )
    #
    # PRIVATE_KEY_PATH.parent.mkdir(parents=True, exist_ok=True)
    # key = Ed25519PrivateKey.generate()
    # PRIVATE_KEY_PATH.write_bytes(
    #     key.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption())
    # )
    # PUBLIC_KEY_PATH.write_bytes(
    #     key.public_key().public_bytes(Encoding.PEM, PublicFormat.SubjectPublicKeyInfo)
    # )
    # print(f"Private key → {PRIVATE_KEY_PATH}  (never commit this)")
    # print(f"Public key  → {PUBLIC_KEY_PATH}  (commit this)")
    raise NotImplementedError("TODO: implement keygen")


if __name__ == "__main__":
    generate_keypair()
