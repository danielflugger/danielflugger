# vera-core

**Private implementation repository for the VERA Sovereign Provenance Protocol.**

Patent Pending — U.S. Application No. 64/000,086  
Filed: March 9, 2026 · Applicant: Dhana LLC

---

## What This Is

The working implementation of the transport interception and cryptographic signing
layer described in U.S. Provisional Patent Application 64/000,086.

Public framework documentation lives at:
- https://github.com/danielflugger/vera (public)
- https://danielflugger.github.io/VERA/ (docs)

This repo is the proprietary engine underneath.

---

## Architecture

```
vera-core/
├── vera/
│   ├── __init__.py
│   ├── keygen.py          # Ed25519 keypair generation
│   ├── sign.py            # Core signing engine (patent claim 1, 8)
│   ├── certificate.py     # Portable session certificate format (patent claim 9)
│   ├── interceptor.py     # MCP transport interception wrapper (patent claim 2)
│   ├── store.py           # Local storage manager (patent claim 10)
│   └── verify.py          # Third-party verification via public key only
├── tests/
│   ├── test_sign.py
│   ├── test_verify.py
│   └── test_certificate.py
├── .vera/
│   ├── sessions/          # Signed session certificates (committed to git)
│   └── keys/
│       └── public.pem     # Public key only — private key NEVER committed
├── hooks/
│   └── post-commit        # Git hook — copy to .git/hooks/post-commit
├── docs/
│   └── PATENT_CLAIMS.md   # Maps each module to its patent claim
├── .gitignore
├── requirements.txt
└── README.md
```

---

## Quick Start (when ready to implement)

```bash
# 1. Generate keypair (one time)
python -m vera.keygen

# 2. Install git hook
cp hooks/post-commit .git/hooks/post-commit
chmod +x .git/hooks/post-commit

# 3. Wrap an LLM call
from vera.sign import sign_session
cert = sign_session(prompt="...", response="...", model="claude-sonnet-4-6")

# 4. Verify a certificate (as third party)
from vera.verify import verify_certificate
valid = verify_certificate("path/to/session.json", "path/to/public.pem")
```

---

## Patent Claim Coverage

| Module | Patent Claim |
|--------|-------------|
| `interceptor.py` | Claim 1, 2 — MCP-compatible transport interception |
| `sign.py` | Claim 8 — offline Ed25519 signing, operator-held key |
| `certificate.py` | Claim 9 — portable, multi-vendor aggregable format |
| `store.py` | Claim 10 — local storage manager, signed session index |
| `verify.py` | Claim 12 — third-party verification via public key only |

---

## Key Design Principles

1. **Offline-first** — signing engine never requires network access
2. **Operator-held keys** — private key generated locally, never transmitted
3. **Vendor-agnostic** — wraps any LLM call regardless of provider
4. **Git-native** — session certificates commit alongside code automatically
5. **Self-verifying** — any certificate verifiable with public key alone

---

## Status

- [ ] Keypair generation (`keygen.py`)
- [ ] Core signing engine (`sign.py`)
- [ ] Certificate format (`certificate.py`)
- [ ] Transport interceptor (`interceptor.py`)
- [ ] Local storage manager (`store.py`)
- [ ] Verification module (`verify.py`)
- [ ] Git hook (`hooks/post-commit`)
- [ ] Test suite
- [ ] GCP integration example
- [ ] Multi-vendor aggregation example

---

*This repository is private and proprietary. All rights reserved. Dhana LLC.*  
*Patent Pending — U.S. Application No. 64/000,086*
