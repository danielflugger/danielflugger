# Patent Claims Reference

**U.S. Provisional Application No. 64/000,086**  
Method and System for Generating Sovereign Provenance Records of AI-Assisted Work Sessions  
Filed: March 9, 2026 · Dhana LLC

This document maps each filed claim to its implementing module.
Use this when writing the non-provisional to demonstrate reduction to practice.

---

## Method Claims

| Claim | Description | Module |
|-------|-------------|--------|
| 1 | Independent — transport interception, provenance record generation, cryptographic signing, local storage, portable certificate | `interceptor.py`, `sign.py`, `store.py`, `certificate.py` |
| 2 | MCP-compatible transport layer | `interceptor.py` → `MCPInterceptor` |
| 3 | Vendor-agnostic operation (cloud + local LLMs) | `interceptor.py` → `VERAInterceptor` |
| 4 | Work product chain of custody | `sign.py` → `_build_record()` with prompt/response |
| 5 | Context state snapshot at each interaction | `sign.py` → `context_snapshot` field |
| 6 | Context state reconstruction from certificate | `verify.py` → `reconstruct_context()` |
| 7 | Offline operation — no network at signing time | `sign.py` → `_load_private_key()` (local only) |
| 8 | Ed25519 signing, operator-held key, never transmitted | `sign.py`, `keygen.py` |
| 9 | Multi-vendor aggregation into single certificate | `certificate.py` → `SessionBundle` |

## System Claims

| Claim | Description | Module |
|-------|-------------|--------|
| 10 | Independent system — processor + memory + five components | All modules |
| 11 | Local storage manager with signed session index | `store.py` → `update_index()` |
| 12 | Third-party verification via public key only | `verify.py` → `verify_certificate()` |
| 13 | Context state reconstruction enabling session replay | `verify.py` → `reconstruct_context()` |

---

## Notes for Non-Provisional

- Reduction to practice: each `TODO` in the skeleton becomes working code
- File non-provisional by **March 9, 2027** (12-month provisional window)
- Consider adding claims for: git hook integration, ranked knowledge layer
  (file separate provisional when ranking system is implemented)
